#ifndef NOTEBOOK_H
#define NOTEBOOK_H
class is defined here 
see the puml(plant uml) file or the .svg(image) for the class diagram that describes the class you need to create.
#endif